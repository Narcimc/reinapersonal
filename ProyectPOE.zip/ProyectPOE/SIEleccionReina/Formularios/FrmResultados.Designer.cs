﻿namespace SIEleccionReina.Formularios
{
    partial class FrmResultados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmResultados));
            this.lblNmb4to = new System.Windows.Forms.Label();
            this.BTNAbrirEstadisticas = new System.Windows.Forms.Button();
            this.lbl1erLG = new System.Windows.Forms.Label();
            this.lblComentario = new System.Windows.Forms.Label();
            this.LblTitulo = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.PBOXDevolverImagen = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lbl2doLG = new System.Windows.Forms.Label();
            this.lbl3LG = new System.Windows.Forms.Label();
            this.lbl4toLG = new System.Windows.Forms.Label();
            this.lbl5toLG = new System.Windows.Forms.Label();
            this.lblNmb2da = new System.Windows.Forms.Label();
            this.lblNmbReina = new System.Windows.Forms.Label();
            this.lblNmb3er = new System.Windows.Forms.Label();
            this.lbl5to = new System.Windows.Forms.Label();
            this.btnAtras = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBOXDevolverImagen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNmb4to
            // 
            this.lblNmb4to.AutoSize = true;
            this.lblNmb4to.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lblNmb4to.Font = new System.Drawing.Font("Stencil", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNmb4to.Location = new System.Drawing.Point(-5, 322);
            this.lblNmb4to.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNmb4to.Name = "lblNmb4to";
            this.lblNmb4to.Size = new System.Drawing.Size(81, 14);
            this.lblNmb4to.TabIndex = 50;
            this.lblNmb4to.Text = "Comentario";
            this.lblNmb4to.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BTNAbrirEstadisticas
            // 
            this.BTNAbrirEstadisticas.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BTNAbrirEstadisticas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BTNAbrirEstadisticas.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BTNAbrirEstadisticas.Font = new System.Drawing.Font("Script MT Bold", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNAbrirEstadisticas.Location = new System.Drawing.Point(545, 377);
            this.BTNAbrirEstadisticas.Margin = new System.Windows.Forms.Padding(2);
            this.BTNAbrirEstadisticas.Name = "BTNAbrirEstadisticas";
            this.BTNAbrirEstadisticas.Size = new System.Drawing.Size(188, 23);
            this.BTNAbrirEstadisticas.TabIndex = 49;
            this.BTNAbrirEstadisticas.Text = "Abrir Informacion Detallada";
            this.BTNAbrirEstadisticas.UseVisualStyleBackColor = false;
            // 
            // lbl1erLG
            // 
            this.lbl1erLG.AutoSize = true;
            this.lbl1erLG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl1erLG.Font = new System.Drawing.Font("Stencil", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1erLG.Location = new System.Drawing.Point(258, 76);
            this.lbl1erLG.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl1erLG.Name = "lbl1erLG";
            this.lbl1erLG.Size = new System.Drawing.Size(231, 14);
            this.lbl1erLG.TabIndex = 48;
            this.lbl1erLG.Text = "Reina de la Universidad (1er lugar)";
            this.lbl1erLG.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblComentario
            // 
            this.lblComentario.AutoSize = true;
            this.lblComentario.Font = new System.Drawing.Font("Microsoft Tai Le", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblComentario.Location = new System.Drawing.Point(164, 299);
            this.lblComentario.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblComentario.Name = "lblComentario";
            this.lblComentario.Size = new System.Drawing.Size(0, 14);
            this.lblComentario.TabIndex = 47;
            this.lblComentario.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblTitulo
            // 
            this.LblTitulo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblTitulo.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.LblTitulo.Location = new System.Drawing.Point(376, 10);
            this.LblTitulo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblTitulo.Name = "LblTitulo";
            this.LblTitulo.Size = new System.Drawing.Size(153, 44);
            this.LblTitulo.TabIndex = 41;
            this.LblTitulo.Text = "Elección Reina de la Facultad de Matemáticas";
            this.LblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::SIEleccionReina.Properties.Resources.descarga__5_;
            this.pictureBox5.Location = new System.Drawing.Point(531, 168);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(96, 142);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 54;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::SIEleccionReina.Properties.Resources.descarga__5_;
            this.pictureBox4.Location = new System.Drawing.Point(105, 168);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(107, 142);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 53;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::SIEleccionReina.Properties.Resources.descarga__5_;
            this.pictureBox3.Location = new System.Drawing.Point(668, 211);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(81, 99);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 52;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::SIEleccionReina.Properties.Resources.descarga__5_;
            this.pictureBox2.Location = new System.Drawing.Point(-6, 211);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(82, 99);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 51;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // PBOXDevolverImagen
            // 
            this.PBOXDevolverImagen.Image = global::SIEleccionReina.Properties.Resources.descarga__5_;
            this.PBOXDevolverImagen.Location = new System.Drawing.Point(261, 106);
            this.PBOXDevolverImagen.Name = "PBOXDevolverImagen";
            this.PBOXDevolverImagen.Size = new System.Drawing.Size(224, 207);
            this.PBOXDevolverImagen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PBOXDevolverImagen.TabIndex = 45;
            this.PBOXDevolverImagen.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(192, 10);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(161, 44);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 42;
            this.pictureBox1.TabStop = false;
            // 
            // lbl2doLG
            // 
            this.lbl2doLG.AutoSize = true;
            this.lbl2doLG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl2doLG.Font = new System.Drawing.Font("Stencil", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2doLG.Location = new System.Drawing.Point(128, 139);
            this.lbl2doLG.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl2doLG.Name = "lbl2doLG";
            this.lbl2doLG.Size = new System.Drawing.Size(69, 14);
            this.lbl2doLG.TabIndex = 55;
            this.lbl2doLG.Text = "2do lugar";
            this.lbl2doLG.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl3LG
            // 
            this.lbl3LG.AutoSize = true;
            this.lbl3LG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl3LG.Font = new System.Drawing.Font("Stencil", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3LG.Location = new System.Drawing.Point(542, 139);
            this.lbl3LG.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl3LG.Name = "lbl3LG";
            this.lbl3LG.Size = new System.Drawing.Size(68, 14);
            this.lbl3LG.TabIndex = 56;
            this.lbl3LG.Text = "3er lugar";
            this.lbl3LG.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl4toLG
            // 
            this.lbl4toLG.AutoSize = true;
            this.lbl4toLG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl4toLG.Font = new System.Drawing.Font("Stencil", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl4toLG.Location = new System.Drawing.Point(7, 181);
            this.lbl4toLG.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl4toLG.Name = "lbl4toLG";
            this.lbl4toLG.Size = new System.Drawing.Size(68, 14);
            this.lbl4toLG.TabIndex = 57;
            this.lbl4toLG.Text = "4to lugar";
            this.lbl4toLG.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl5toLG
            // 
            this.lbl5toLG.AutoSize = true;
            this.lbl5toLG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl5toLG.Font = new System.Drawing.Font("Stencil", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl5toLG.Location = new System.Drawing.Point(665, 181);
            this.lbl5toLG.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl5toLG.Name = "lbl5toLG";
            this.lbl5toLG.Size = new System.Drawing.Size(68, 14);
            this.lbl5toLG.TabIndex = 58;
            this.lbl5toLG.Text = "5to lugar";
            this.lbl5toLG.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNmb2da
            // 
            this.lblNmb2da.AutoSize = true;
            this.lblNmb2da.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lblNmb2da.Font = new System.Drawing.Font("Stencil", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNmb2da.Location = new System.Drawing.Point(116, 322);
            this.lblNmb2da.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNmb2da.Name = "lblNmb2da";
            this.lblNmb2da.Size = new System.Drawing.Size(55, 14);
            this.lblNmb2da.TabIndex = 59;
            this.lblNmb2da.Text = "Nombre";
            this.lblNmb2da.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNmbReina
            // 
            this.lblNmbReina.AutoSize = true;
            this.lblNmbReina.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lblNmbReina.Font = new System.Drawing.Font("Stencil", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNmbReina.Location = new System.Drawing.Point(322, 322);
            this.lblNmbReina.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNmbReina.Name = "lblNmbReina";
            this.lblNmbReina.Size = new System.Drawing.Size(55, 14);
            this.lblNmbReina.TabIndex = 60;
            this.lblNmbReina.Text = "Nombre";
            this.lblNmbReina.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNmb3er
            // 
            this.lblNmb3er.AutoSize = true;
            this.lblNmb3er.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lblNmb3er.Font = new System.Drawing.Font("Stencil", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNmb3er.Location = new System.Drawing.Point(542, 322);
            this.lblNmb3er.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNmb3er.Name = "lblNmb3er";
            this.lblNmb3er.Size = new System.Drawing.Size(81, 14);
            this.lblNmb3er.TabIndex = 61;
            this.lblNmb3er.Text = "Comentario";
            this.lblNmb3er.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl5to
            // 
            this.lbl5to.AutoSize = true;
            this.lbl5to.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lbl5to.Font = new System.Drawing.Font("Stencil", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl5to.Location = new System.Drawing.Point(679, 322);
            this.lbl5to.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl5to.Name = "lbl5to";
            this.lbl5to.Size = new System.Drawing.Size(81, 14);
            this.lbl5to.TabIndex = 62;
            this.lbl5to.Text = "Comentario";
            this.lbl5to.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnAtras
            // 
            this.btnAtras.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnAtras.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnAtras.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAtras.Font = new System.Drawing.Font("Script MT Bold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAtras.Location = new System.Drawing.Point(-2, 377);
            this.btnAtras.Margin = new System.Windows.Forms.Padding(2);
            this.btnAtras.Name = "btnAtras";
            this.btnAtras.Size = new System.Drawing.Size(48, 25);
            this.btnAtras.TabIndex = 63;
            this.btnAtras.Text = "Atras";
            this.btnAtras.UseVisualStyleBackColor = false;
            this.btnAtras.Click += new System.EventHandler(this.btnAtras_Click);
            // 
            // FrmResultados
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SIEleccionReina.Properties.Resources.fondoazul;
            this.ClientSize = new System.Drawing.Size(760, 411);
            this.Controls.Add(this.btnAtras);
            this.Controls.Add(this.lbl5to);
            this.Controls.Add(this.lblNmb3er);
            this.Controls.Add(this.lblNmbReina);
            this.Controls.Add(this.lblNmb2da);
            this.Controls.Add(this.lbl5toLG);
            this.Controls.Add(this.lbl4toLG);
            this.Controls.Add(this.lbl3LG);
            this.Controls.Add(this.lbl2doLG);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.lblNmb4to);
            this.Controls.Add(this.BTNAbrirEstadisticas);
            this.Controls.Add(this.lbl1erLG);
            this.Controls.Add(this.lblComentario);
            this.Controls.Add(this.PBOXDevolverImagen);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.LblTitulo);
            this.Name = "FrmResultados";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBOXDevolverImagen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lblNmb4to;
        private System.Windows.Forms.Button BTNAbrirEstadisticas;
        private System.Windows.Forms.Label lbl1erLG;
        private System.Windows.Forms.Label lblComentario;
        private System.Windows.Forms.PictureBox PBOXDevolverImagen;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label LblTitulo;
        private System.Windows.Forms.Label lbl2doLG;
        private System.Windows.Forms.Label lbl3LG;
        private System.Windows.Forms.Label lbl4toLG;
        private System.Windows.Forms.Label lbl5toLG;
        private System.Windows.Forms.Label lblNmb2da;
        private System.Windows.Forms.Label lblNmbReina;
        private System.Windows.Forms.Label lblNmb3er;
        private System.Windows.Forms.Label lbl5to;
        private System.Windows.Forms.Button btnAtras;
    }
}