﻿using SIEleccionReina.Formularios;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SIEleccionReina
{
    public partial class ModuloAdministrador : Form
    {
        public ModuloAdministrador()
        {
            InitializeComponent();
        }

        private void ModuloAdministrador_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            FrmResultados vResultados = new FrmResultados();
            vResultados.Show();
        }

        private void BtnInscripcionCandidatas_Click(object sender, EventArgs e)
        {
            this.Hide();
            RegistroDeCandidatas vRegistroCand = new RegistroDeCandidatas();
            vRegistroCand.Show();
        }

        private void BtnRegistroFoto_Click(object sender, EventArgs e)
        {
            this.Hide();
            FRMGaleriaFotos vGaleriaFot = new FRMGaleriaFotos();
            vGaleriaFot.Show();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            FRMSemestre vSemestre = new FRMSemestre();
            vSemestre.Show();
        }

        private void btnRgstrCarrera_Click(object sender, EventArgs e)
        {
            this.Hide();
            FRMCarreras vCarrera = new FRMCarreras();
            vCarrera.Show();
        }
    }
}
