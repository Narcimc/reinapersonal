﻿namespace SIEleccionReina.Formularios
{
    partial class FrmResultadosFotogenica
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmResultadosFotogenica));
            this.lbltituloFotogenica = new System.Windows.Forms.Label();
            this.LblTitulo = new System.Windows.Forms.Label();
            this.PBOXDevolverImagen = new System.Windows.Forms.PictureBox();
            this.LblNmbFotogenica = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.BtnFotogenica = new System.Windows.Forms.Button();
            this.btnAtras = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.PBOXDevolverImagen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbltituloFotogenica
            // 
            this.lbltituloFotogenica.AutoSize = true;
            this.lbltituloFotogenica.BackColor = System.Drawing.Color.Teal;
            this.lbltituloFotogenica.Font = new System.Drawing.Font("Stencil", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltituloFotogenica.Location = new System.Drawing.Point(30, 75);
            this.lbltituloFotogenica.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbltituloFotogenica.Name = "lbltituloFotogenica";
            this.lbltituloFotogenica.Size = new System.Drawing.Size(240, 16);
            this.lbltituloFotogenica.TabIndex = 50;
            this.lbltituloFotogenica.Text = "Miss Fotogenica de la universidad";
            this.lbltituloFotogenica.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblTitulo
            // 
            this.LblTitulo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblTitulo.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.LblTitulo.Location = new System.Drawing.Point(181, 15);
            this.LblTitulo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblTitulo.Name = "LblTitulo";
            this.LblTitulo.Size = new System.Drawing.Size(153, 44);
            this.LblTitulo.TabIndex = 49;
            this.LblTitulo.Text = "Elección Reina de la Facultad de Matemáticas";
            this.LblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PBOXDevolverImagen
            // 
            this.PBOXDevolverImagen.Image = global::SIEleccionReina.Properties.Resources.descarga__5_;
            this.PBOXDevolverImagen.Location = new System.Drawing.Point(47, 103);
            this.PBOXDevolverImagen.Name = "PBOXDevolverImagen";
            this.PBOXDevolverImagen.Size = new System.Drawing.Size(208, 226);
            this.PBOXDevolverImagen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PBOXDevolverImagen.TabIndex = 47;
            this.PBOXDevolverImagen.TabStop = false;
            // 
            // LblNmbFotogenica
            // 
            this.LblNmbFotogenica.AutoSize = true;
            this.LblNmbFotogenica.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.LblNmbFotogenica.Font = new System.Drawing.Font("Stencil", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblNmbFotogenica.Location = new System.Drawing.Point(69, 335);
            this.LblNmbFotogenica.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblNmbFotogenica.Name = "LblNmbFotogenica";
            this.LblNmbFotogenica.Size = new System.Drawing.Size(156, 14);
            this.LblNmbFotogenica.TabIndex = 45;
            this.LblNmbFotogenica.Text = "Nombre de la Candidata";
            this.LblNmbFotogenica.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(3, 15);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(161, 44);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 44;
            this.pictureBox1.TabStop = false;
            // 
            // BtnFotogenica
            // 
            this.BtnFotogenica.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BtnFotogenica.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BtnFotogenica.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnFotogenica.Font = new System.Drawing.Font("Script MT Bold", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnFotogenica.Location = new System.Drawing.Point(196, 376);
            this.BtnFotogenica.Margin = new System.Windows.Forms.Padding(2);
            this.BtnFotogenica.Name = "BtnFotogenica";
            this.BtnFotogenica.Size = new System.Drawing.Size(138, 23);
            this.BtnFotogenica.TabIndex = 51;
            this.BtnFotogenica.Text = "Ver Detalle de Resultados";
            this.BtnFotogenica.UseVisualStyleBackColor = false;
            this.BtnFotogenica.Click += new System.EventHandler(this.BtnFotogenica_Click);
            // 
            // btnAtras
            // 
            this.btnAtras.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnAtras.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnAtras.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAtras.Font = new System.Drawing.Font("Script MT Bold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAtras.Location = new System.Drawing.Point(3, 376);
            this.btnAtras.Margin = new System.Windows.Forms.Padding(2);
            this.btnAtras.Name = "btnAtras";
            this.btnAtras.Size = new System.Drawing.Size(40, 23);
            this.btnAtras.TabIndex = 52;
            this.btnAtras.Text = "Atras";
            this.btnAtras.UseVisualStyleBackColor = false;
            this.btnAtras.Click += new System.EventHandler(this.btnAtras_Click);
            // 
            // FrmResultadosFotogenica
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SIEleccionReina.Properties.Resources.fondoLogin;
            this.ClientSize = new System.Drawing.Size(339, 401);
            this.Controls.Add(this.btnAtras);
            this.Controls.Add(this.BtnFotogenica);
            this.Controls.Add(this.lbltituloFotogenica);
            this.Controls.Add(this.LblTitulo);
            this.Controls.Add(this.PBOXDevolverImagen);
            this.Controls.Add(this.LblNmbFotogenica);
            this.Controls.Add(this.pictureBox1);
            this.Name = "FrmResultadosFotogenica";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.PBOXDevolverImagen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbltituloFotogenica;
        private System.Windows.Forms.Label LblTitulo;
        private System.Windows.Forms.PictureBox PBOXDevolverImagen;
        private System.Windows.Forms.Label LblNmbFotogenica;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button BtnFotogenica;
        private System.Windows.Forms.Button btnAtras;
    }
}