﻿using SIEleccionReina.AccesoDatos;
using SIEleccionReina.Entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SIEleccionReina.Formularios
{
    public partial class FRMVotoReina : Form
    {
        public FRMVotoReina()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void LblNmbCandidata_Click(object sender, EventArgs e)
        {
            cargardatosUsuario();
        }
        public void cargardatosUsuario()
        {
            

            

            DataTable tb = new DataTable();
            clsCandidata_DB Obj_conexion = new clsCandidata_DB();
            //clsCandidatas Obj_Candidata = new clsCandidatas();

            

            clsCandidatas Obj_Candi = new clsCandidatas()
            {
                Id_candidata = Convert.ToInt32(LblNmbCandidata)
            };
            tb = Obj_conexion.Combo_Candidata(Obj_Candi, 1);

            tb = Obj_conexion.Obtener_Candidata(Obj_Candi, 10);

            if (tb.Rows.Count > 0)
            {
                foreach (DataRow item in tb.Rows)
                {
                    LblNmbCandidata.Text = "Nombre: " + item["nombre"].ToString() + item["apellido"].ToString();
                    // TxtApellido.Text = item["apellido"].ToString();
                    PBOXDevolverImagen.Image = Base64ToImage(item["foto"].ToString());
                    //lblEdad.Text = item["edad"].ToString() + " Anios";
                    ////TxtFechaNacimiento.Text = ((DateTime)item["fecha_nacimiento"]).ToShortDateString().ToString();
                    //lblCarrera.Text = "Carrera: " + item["nombre_carrera"].ToString();
                    //lblSemestre.Text = "Semestre: " + item["numero_semestre"].ToString();
                    //lblAspitacionesDato.Text = item["aspiraciones"].ToString();
                    //lblHabilidadesDatos.Text = item["habilidades"].ToString();
                    //lblInteresDato.Text = item["intereses"].ToString();
                }
            }
        }
        public Image Base64ToImage(string base64String)
        {
            // Convert Base64 String to byte[]
            byte[] imageBytes = Convert.FromBase64String(base64String);
            MemoryStream ms = new MemoryStream(imageBytes, 0,
              imageBytes.Length);

            // Convert byte[] to Image
            ms.Write(imageBytes, 0, imageBytes.Length);
            Image image = Image.FromStream(ms, true);
            return image;
        }

        private void BTNVotar_Click(object sender, EventArgs e)
        {
            BTNVotar.Enabled = false;
            MessageBox.Show("¡VOTACION EXITOSA!", "VOTACION" , MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtnFotogenica_Click(object sender, EventArgs e)
        {
            FrmVotarFotogenica votoFotogenica = new FrmVotarFotogenica();
            votoFotogenica.Show();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
